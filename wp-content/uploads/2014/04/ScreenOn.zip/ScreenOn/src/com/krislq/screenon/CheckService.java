package com.krislq.screenon;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
/**
 * 
 * @{#} CheckService.java Create on 2014-3-15 上午9:57:25    
 *    
 * class desc:   
 *
 * <p>Copyright: Copyright(c) 2013 </p> 
 * <p>Company: icarsclub</p>
 * @Version 1.0
 * @Author <a href="mailto:kris@ppzuche.com">kris</a>   
 *  
 *
 */
public class CheckService extends Service{
    public static final String ACTION_CHECK = "com.krislq.screenon.service.CHECK";

    private ScreenReceiver mScreenReceiver;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        log("onCreate");
        super.onCreate();
        mScreenReceiver = new ScreenReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(mScreenReceiver, filter);
    }

    public void log(String msg) {
        if(TextUtils.isEmpty(msg)) {
            return;
        }
        Log.e("CheckService", msg);
    }
    @Override
    public void onDestroy() {
        log("onDestroy");
        unregisterReceiver(mScreenReceiver);
        super.onDestroy();
    }
}
