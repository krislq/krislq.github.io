package com.krislq.screenon;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
/**
 * 
 * @{#} ScreenReceiver.java Create on 2014-3-19 下午5:57:38    
 *    
 * class desc:   
 *
 * <p>Copyright: Copyright(c) 2013 </p> 
 * <p>Company: icarsclub</p>
 * @Version 1.0
 *  
 *
 */
public class ScreenReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)){
            Log.e("ScreenReceiver", "ACTION_SCREEN_ON");
        } else if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)){
            Log.e("ScreenReceiver", "ACTION_SCREEN_OFF");
        }else if (intent.getAction().equals(Intent.ACTION_USER_PRESENT)){
            Log.e("ScreenReceiver", "ACTION_USER_PRESENT");
        }
    }

}
